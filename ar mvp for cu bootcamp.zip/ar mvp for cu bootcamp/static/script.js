// import * as THREE from 'three';
// import { ARButton } from 'three/examples/jsm/webxr/ARButton.js';
// import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

// let scene, camera, renderer, model, mixer;

// init();
// animate();

// function init() {
//     renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
//     renderer.setSize(window.innerWidth, window.innerHeight);
//     renderer.xr.enabled = true;
//     document.body.appendChild(renderer.domElement);
//     document.body.appendChild(ARButton.createButton(renderer));

//     scene = new THREE.Scene();
//     camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.01, 20);
//     let light = new THREE.HemisphereLight(0xffffff, 0xbbbbff, 1);
//     scene.add(light);

//     let loader = new GLTFLoader();
//     loader.load('/models/model.glb', (gltf) => {
//         model = gltf.scene;
//         scene.add(model);

//         mixer = new THREE.AnimationMixer(model);
//         gltf.animations.forEach((clip) => mixer.clipAction(clip).play());
//     });
// }

// function animate() {
//     renderer.setAnimationLoop(() => {
//         if (mixer) mixer.update(0.02);
//         renderer.render(scene, camera);
//     });
// }
